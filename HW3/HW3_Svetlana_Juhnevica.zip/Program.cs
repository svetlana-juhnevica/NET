﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW3
{
    class Program
    {
        static void Main(string[] args)
        {
           // Tasks task1 = new Tasks();
           //task1.Task1();
          // Tasks task2 = new Tasks();
          //  task2.Task2();
          //  Tasks task3 = new Tasks();
          //  task3.Task3();
          //  Tasks task4 = new Tasks();
          //  task4.Task4();
          //  Tasks task5 = new Tasks();
          //  task5.Task5();
            Tasks task6 = new Tasks();
            task6.Task6();
          
        }
    }
}
