﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BicycleRental
{
    class Bicycle
    {
       
            public int Number;
            public string Name;
            

            public Bicycle(int number, string name)// konstruktor
            {
                Number = number;
                Name = name;
                

            }
        }
    }



